import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

// Simple CSV parser that handles quoted fields
function parseCSV(text: string): string[][] {
  const lines: string[][] = []
  let currentLine: string[] = []
  let currentField = ""
  let insideQuotes = false

  for (let i = 0; i < text.length; i++) {
    const char = text[i]
    const nextChar = text[i + 1]

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        // Escaped quote
        currentField += '"'
        i++ // Skip next quote
      } else {
        // Toggle quote state
        insideQuotes = !insideQuotes
      }
    } else if (char === "," && !insideQuotes) {
      // Field separator
      currentLine.push(currentField.trim())
      currentField = ""
    } else if ((char === "\n" || char === "\r") && !insideQuotes) {
      // Line separator
      if (currentField || currentLine.length > 0) {
        currentLine.push(currentField.trim())
        if (currentLine.some((field) => field.length > 0)) {
          lines.push(currentLine)
        }
        currentLine = []
        currentField = ""
      }
      // Skip \r\n
      if (char === "\r" && nextChar === "\n") {
        i++
      }
    } else {
      currentField += char
    }
  }

  // Add last field and line
  if (currentField || currentLine.length > 0) {
    currentLine.push(currentField.trim())
    if (currentLine.some((field) => field.length > 0)) {
      lines.push(currentLine)
    }
  }

  return lines
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const file = formData.get("file") as File
    const fileType = formData.get("type") as "areas" | "rides"

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    const text = await file.text()
    const lines = parseCSV(text)

    if (lines.length < 2) {
      return NextResponse.json({ error: "CSV file is empty or has no data rows" }, { status: 400 })
    }

    const headers = lines[0]
    const sql = neon(process.env.DATABASE_URL!)

    if (fileType === "areas") {
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i]

        const row: Record<string, any> = {}
        headers.forEach((header, idx) => {
          row[header] = values[idx] || ""
        })

        const { area_id, zone_id, area_name, zone_name, latitude, longitude } = row

        // Handle both "area_id" and "zone_id" column names
        const zoneId = area_id || zone_id
        const zoneName = area_name || zone_name

        if (!zoneId || !latitude || !longitude) {
          console.warn(`Skipping row ${i}: missing required fields`)
          continue
        }

        await sql`
          INSERT INTO area_zones (zone_id, zone_name, latitude, longitude)
          VALUES (${Number.parseInt(zoneId)}, ${zoneName}, ${Number.parseFloat(latitude)}, ${Number.parseFloat(longitude)})
          ON CONFLICT (zone_id) DO NOTHING
        `
      }
    } else if (fileType === "rides") {
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i]

        const row: Record<string, any> = {}
        headers.forEach((header, idx) => {
          row[header] = values[idx] || ""
        })

        // Handle multiple possible column name variations
        const {
          ride_id,
          timestamp,
          pickup_datetime,
          pickup_time,
          dropoff_datetime,
          pickup_area_id,
          pickup_zone,
          pickup_zone_id,
          drop_area_id,
          dropoff_zone,
          dropoff_zone_id,
          trip_distance_km,
          distance,
          fare,
          fare_amount,
          surge_multiplier,
          surge_pricing_applied,
        } = row

        // Determine which columns to use
        const pickupTime = timestamp || pickup_datetime || pickup_time
        const pickupZoneId = pickup_area_id || pickup_zone || pickup_zone_id
        const dropoffZoneId = drop_area_id || dropoff_zone || dropoff_zone_id
        const tripDistance = trip_distance_km || distance
        const fareAmount = fare || fare_amount
        const surgeMult = surge_multiplier || surge_pricing_applied

        if (!pickupTime || !pickupZoneId || !dropoffZoneId || !fareAmount) {
          console.warn(`Skipping row ${i}: missing required fields`)
          continue
        }

        const parsedDate = new Date(pickupTime)
        if (isNaN(parsedDate.getTime())) {
          console.warn(`Skipping row ${i}: invalid timestamp "${pickupTime}"`)
          continue
        }

        await sql`
          INSERT INTO ride_data (
            pickup_zone_id,
            dropoff_zone_id,
            pickup_time,
            fare_amount,
            trip_distance,
            surge_multiplier
          )
          VALUES (
            ${Number.parseInt(pickupZoneId)},
            ${Number.parseInt(dropoffZoneId)},
            ${parsedDate.toISOString()},
            ${Number.parseFloat(fareAmount)},
            ${tripDistance ? Number.parseFloat(tripDistance) : 0},
            ${surgeMult ? Number.parseFloat(surgeMult) : 1}
          )
        `
      }
    }

    return NextResponse.json({
      success: true,
      message: `${fileType === "areas" ? "Area zones" : "Ride data"} uploaded successfully`,
    })
  } catch (error) {
    console.error("[v0] Upload error:", error)
    return NextResponse.json(
      {
        error: "Upload failed",
        details: (error as Error).message,
      },
      { status: 500 },
    )
  }
}
