"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

export default function AnalyticsSummary() {
  const [stats, setStats] = useState({
    totalRides: 0,
    avgSurge: 1.0,
    revenue: 0,
    topZone: "Koramangala",
  })

  const [demandData, setDemandData] = useState([
    { hour: "12AM", demand: 45, surge: 1.2 },
    { hour: "3AM", demand: 30, surge: 1.0 },
    { hour: "6AM", demand: 60, surge: 1.3 },
    { hour: "9AM", demand: 120, surge: 1.8 },
    { hour: "12PM", demand: 95, surge: 1.5 },
    { hour: "3PM", demand: 110, surge: 1.6 },
    { hour: "6PM", demand: 180, surge: 2.1 },
    { hour: "9PM", demand: 150, surge: 1.9 },
  ])

  const [zoneData, setZoneData] = useState([
    { zone: "Koramangala", rides: 450, cancellation: 12, rating: 4.7 },
    { zone: "Indiranagar", rides: 380, cancellation: 8, rating: 4.8 },
    { zone: "MG Road", rides: 520, cancellation: 15, rating: 4.5 },
    { zone: "Whitefield", rides: 290, cancellation: 10, rating: 4.6 },
    { zone: "Yelahanka", rides: 410, cancellation: 7, rating: 4.9 },
  ])

  useEffect(() => {
    const totalRides = zoneData.reduce((sum, z) => sum + z.rides, 0)
    const avgSurge = (demandData.reduce((sum, d) => sum + d.surge, 0) / demandData.length).toFixed(2)
    const revenue = (totalRides * 15 * avgSurge).toFixed(2)
    const topZone = zoneData.reduce((max, z) => (z.rides > max.rides ? z : max)).zone

    setStats({
      totalRides,
      avgSurge: Number.parseFloat(avgSurge),
      revenue: Number.parseFloat(revenue),
      topZone,
    })
  }, [demandData, zoneData])

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total Rides</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-cyan-400">{stats.totalRides.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">Last 24 hours</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Avg Surge</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-pink-500">{stats.avgSurge.toFixed(2)}x</div>
            <p className="text-xs text-gray-500 mt-1">Multiplier</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-400">${stats.revenue.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">Estimated</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Top Zone</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-400">{stats.topZone}</div>
            <p className="text-xs text-gray-500 mt-1">Highest demand</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hourly Demand & Surge */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-cyan-400">Hourly Demand & Surge</CardTitle>
            <CardDescription>24-hour demand pattern</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={demandData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="hour" stroke="#666" />
                <YAxis stroke="#666" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1a1a1a", border: "1px solid #333" }}
                  labelStyle={{ color: "#fff" }}
                />
                <Line type="monotone" dataKey="demand" stroke="#06b6d4" name="Demand" />
                <Line type="monotone" dataKey="surge" stroke="#ec4899" name="Surge" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Zone Performance */}
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-cyan-400">Zone Performance</CardTitle>
            <CardDescription>Rides, cancellation rate, and driver ratings by zone</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={zoneData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="zone" stroke="#666" angle={-45} textAnchor="end" height={80} />
                <YAxis stroke="#666" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1a1a1a", border: "1px solid #333" }}
                  labelStyle={{ color: "#fff" }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload
                      return (
                        <div className="bg-gray-900 p-3 rounded border border-gray-700 text-xs">
                          <p className="text-white font-semibold">{data.zone}</p>
                          <p className="text-cyan-400">Rides: {data.rides}</p>
                          <p className="text-yellow-400">Cancel: {data.cancellation}%</p>
                          <p className="text-green-400">Rating: {data.rating}⭐</p>
                        </div>
                      )
                    }
                    return null
                  }}
                />
                <Bar dataKey="rides" fill="#a78bfa" name="Rides" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
