"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"

export default function DemandForecast() {
  const zoneNames = {
    zone1: "Koramangala",
    zone2: "Indiranagar",
    zone3: "MG Road",
    zone4: "Whitefield",
    zone5: "Yelahanka",
  }

  const [forecast] = useState([
    { hour: "12AM", zone1: 50, zone2: 45, zone3: 60, zone4: 40, zone5: 55 },
    { hour: "2AM", zone1: 30, zone2: 28, zone3: 35, zone4: 25, zone5: 32 },
    { hour: "4AM", zone1: 40, zone2: 38, zone3: 45, zone4: 35, zone5: 42 },
    { hour: "6AM", zone1: 75, zone2: 70, zone3: 85, zone4: 65, zone5: 78 },
    { hour: "8AM", zone1: 140, zone2: 130, zone3: 155, zone4: 120, zone5: 145 },
    { hour: "10AM", zone1: 120, zone2: 110, zone3: 130, zone4: 100, zone5: 125 },
    { hour: "12PM", zone1: 100, zone2: 95, zone3: 110, zone4: 85, zone5: 105 },
    { hour: "2PM", zone1: 90, zone2: 85, zone3: 100, zone4: 75, zone5: 95 },
    { hour: "4PM", zone1: 110, zone2: 105, zone3: 120, zone4: 95, zone5: 115 },
    { hour: "6PM", zone1: 200, zone2: 190, zone3: 215, zone4: 175, zone5: 205 },
    { hour: "8PM", zone1: 180, zone2: 170, zone3: 195, zone4: 155, zone5: 185 },
    { hour: "10PM", zone1: 140, zone2: 130, zone3: 155, zone4: 120, zone5: 145 },
  ])

  const zoneColors = {
    zone1: "#06b6d4",
    zone2: "#ec4899",
    zone3: "#a78bfa",
    zone4: "#10b981",
    zone5: "#f59e0b",
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-cyan-400">24-Hour Demand Forecast by Zone</CardTitle>
          <CardDescription>AI-predicted demand for each zone over the next 24 hours</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={forecast}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="hour" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip
                contentStyle={{ backgroundColor: "#1a1a1a", border: "1px solid #333" }}
                labelStyle={{ color: "#fff" }}
              />
              <Legend />
              <Line type="monotone" dataKey="zone1" stroke={zoneColors.zone1} name={zoneNames.zone1} />
              <Line type="monotone" dataKey="zone2" stroke={zoneColors.zone2} name={zoneNames.zone2} />
              <Line type="monotone" dataKey="zone3" stroke={zoneColors.zone3} name={zoneNames.zone3} />
              <Line type="monotone" dataKey="zone4" stroke={zoneColors.zone4} name={zoneNames.zone4} />
              <Line type="monotone" dataKey="zone5" stroke={zoneColors.zone5} name={zoneNames.zone5} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {Object.entries(zoneNames).map((entry, idx) => {
          const [key, name] = entry
          return (
            <Card key={key} className="bg-gray-900 border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-gray-400">{name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-cyan-400">1.{8 + idx}x</div>
                <p className="text-xs text-gray-500 mt-1">Peak surge multiplier</p>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
