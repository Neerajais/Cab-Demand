"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HeatmapVisualization() {
  const [selectedHour, setSelectedHour] = useState(18)

  const zones = [
    { id: 1, name: "Koramangala", demand: 85, cancellationRate: 12, driverRating: 4.7, revenue: 2450 },
    { id: 2, name: "Indiranagar", demand: 92, cancellationRate: 8, driverRating: 4.8, revenue: 2890 },
    { id: 3, name: "MG Road", demand: 45, cancellationRate: 15, driverRating: 4.5, revenue: 1250 },
    { id: 4, name: "Whitefield", demand: 68, cancellationRate: 10, driverRating: 4.6, revenue: 1890 },
    { id: 5, name: "Yelahanka", demand: 95, cancellationRate: 7, driverRating: 4.9, revenue: 3120 },
    { id: 6, name: "Majestic", demand: 52, cancellationRate: 18, driverRating: 4.4, revenue: 1450 },
    { id: 7, name: "Hebbal", demand: 72, cancellationRate: 11, driverRating: 4.7, revenue: 2050 },
    { id: 8, name: "Jayanagar", demand: 38, cancellationRate: 14, driverRating: 4.6, revenue: 980 },
    { id: 9, name: "Brookefield", demand: 61, cancellationRate: 9, driverRating: 4.8, revenue: 1750 },
  ]

  const getDemandColor = (demand) => {
    if (demand >= 85) return "bg-red-600"
    if (demand >= 70) return "bg-orange-500"
    if (demand >= 55) return "bg-yellow-500"
    if (demand >= 40) return "bg-green-500"
    return "bg-blue-600"
  }

  return (
    <div className="space-y-6">
      {/* Hour Slider */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-cyan-400">Select Time</CardTitle>
          <CardDescription>Choose hour to view demand heatmap</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="0"
              max="23"
              value={selectedHour}
              onChange={(e) => setSelectedHour(Number.parseInt(e.target.value))}
              className="flex-1"
            />
            <span className="text-2xl font-bold text-pink-500 w-20 text-right">
              {String(selectedHour).padStart(2, "0")}:00
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Heatmap Grid */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-cyan-400">Demand Heatmap by Zone</CardTitle>
          <CardDescription>Real-time demand intensity with zone metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {zones.map((zone) => {
              // Adjust demand based on selected hour
              let hourlyDemand = zone.demand
              if (selectedHour >= 8 && selectedHour <= 10) hourlyDemand = Math.min(95, zone.demand + 20)
              if (selectedHour >= 17 && selectedHour <= 19) hourlyDemand = Math.min(99, zone.demand + 25)
              if (selectedHour >= 0 && selectedHour <= 5) hourlyDemand = Math.max(20, zone.demand - 40)

              return (
                <div
                  key={zone.id}
                  className={`p-6 rounded-lg ${getDemandColor(hourlyDemand)} transition-all duration-300 cursor-pointer hover:shadow-lg hover:shadow-cyan-500/50`}
                >
                  <p className="text-white font-bold text-lg mb-2">{zone.name}</p>
                  <p className="text-white text-3xl font-bold mb-3">{hourlyDemand}%</p>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between bg-black/30 p-2 rounded">
                      <span className="text-gray-200">Cancel Rate:</span>
                      <span className="font-semibold text-yellow-300">{zone.cancellationRate}%</span>
                    </div>
                    <div className="flex justify-between bg-black/30 p-2 rounded">
                      <span className="text-gray-200">Driver Rating:</span>
                      <span className="font-semibold text-green-300">⭐ {zone.driverRating}</span>
                    </div>
                    <div className="flex justify-between bg-black/30 p-2 rounded">
                      <span className="text-gray-200">Hourly Revenue:</span>
                      <span className="font-semibold text-cyan-300">${zone.revenue}</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Legend */}
          <div className="mt-8 p-4 bg-gray-800 rounded-lg">
            <p className="text-gray-400 text-sm font-semibold mb-3">Demand Legend</p>
            <div className="flex items-center gap-4 flex-wrap text-xs">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-red-600 rounded"></div>
                <span className="text-gray-400">{">"} 85%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-orange-500 rounded"></div>
                <span className="text-gray-400">70-85%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                <span className="text-gray-400">55-70%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-500 rounded"></div>
                <span className="text-gray-400">40-55%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-blue-600 rounded"></div>
                <span className="text-gray-400">{"<"} 40%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
