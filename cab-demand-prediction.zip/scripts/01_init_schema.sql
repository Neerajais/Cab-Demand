-- Area Zones Table
CREATE TABLE IF NOT EXISTS area_zones (
  id SERIAL PRIMARY KEY,
  zone_id INT NOT NULL UNIQUE,
  zone_name VARCHAR(255) NOT NULL,
  latitude FLOAT NOT NULL,
  longitude FLOAT NOT NULL,
  area_category VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ride Data Table
CREATE TABLE IF NOT EXISTS ride_data (
  id SERIAL PRIMARY KEY,
  pickup_zone_id INT NOT NULL,
  dropoff_zone_id INT NOT NULL,
  pickup_time TIMESTAMP NOT NULL,
  dropoff_time TIMESTAMP,
  fare_amount FLOAT,
  trip_distance FLOAT,
  passenger_count INT,
  payment_type VARCHAR(50),
  surge_multiplier FLOAT DEFAULT 1.0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (pickup_zone_id) REFERENCES area_zones(zone_id),
  FOREIGN KEY (dropoff_zone_id) REFERENCES area_zones(zone_id)
);

-- Demand Predictions Table
CREATE TABLE IF NOT EXISTS demand_predictions (
  id SERIAL PRIMARY KEY,
  zone_id INT NOT NULL,
  prediction_time TIMESTAMP NOT NULL,
  predicted_demand FLOAT,
  predicted_surge_multiplier FLOAT,
  confidence_score FLOAT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (zone_id) REFERENCES area_zones(zone_id)
);

-- Daily Analytics Table
CREATE TABLE IF NOT EXISTS daily_analytics (
  id SERIAL PRIMARY KEY,
  zone_id INT NOT NULL,
  date DATE NOT NULL,
  total_rides INT,
  total_revenue FLOAT,
  avg_surge_multiplier FLOAT,
  peak_hour INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (zone_id) REFERENCES area_zones(zone_id),
  UNIQUE(zone_id, date)
);

-- Create indexes for better query performance
CREATE INDEX idx_ride_pickup_time ON ride_data(pickup_time);
CREATE INDEX idx_ride_zone ON ride_data(pickup_zone_id, dropoff_zone_id);
CREATE INDEX idx_predictions_zone_time ON demand_predictions(zone_id, prediction_time);
CREATE INDEX idx_analytics_zone_date ON daily_analytics(zone_id, date);
