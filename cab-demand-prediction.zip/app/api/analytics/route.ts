import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET(req: NextRequest) {
  try {
    const sql = neon(process.env.DATABASE_URL!)

    // Get today's analytics
    const analytics = await sql`
      SELECT 
        az.zone_id,
        az.zone_name,
        COUNT(rd.id) as total_rides,
        COALESCE(SUM(rd.fare_amount), 0) as total_revenue,
        COALESCE(AVG(rd.surge_multiplier), 1.0) as avg_surge,
        EXTRACT(HOUR FROM MAX(rd.pickup_time)) as peak_hour
      FROM ride_data rd
      JOIN area_zones az ON rd.pickup_zone_id = az.zone_id
      WHERE DATE(rd.pickup_time) = CURRENT_DATE
      GROUP BY az.zone_id, az.zone_name
      ORDER BY total_rides DESC
    `

    return NextResponse.json(analytics)
  } catch (error) {
    console.error("Analytics fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch analytics" }, { status: 500 })
  }
}
