"use client"

import { useState, useMemo } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
} from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function GeoSpatialMap() {
  const [selectedZone, setSelectedZone] = useState(null)

  // Geo-heatmap data with latitude/longitude
  const hotspots = [
    { zone: "Koramangala", lat: 12.9352, lon: 77.6245, intensity: 85, cancellations: 12 },
    { zone: "Indiranagar", lat: 12.9716, lon: 77.6412, intensity: 92, cancellations: 8 },
    { zone: "MG Road", lat: 12.9352, lon: 77.6299, intensity: 95, cancellations: 15 },
    { zone: "Whitefield", lat: 12.9698, lon: 77.7499, intensity: 78, cancellations: 5 },
    { zone: "Yelahanka", lat: 13.0859, lon: 77.5974, intensity: 65, cancellations: 3 },
    { zone: "Majestic", lat: 12.9698, lon: 77.5805, intensity: 88, cancellations: 14 },
    { zone: "Hebbal", lat: 13.0259, lon: 77.5985, intensity: 72, cancellations: 6 },
    { zone: "Jayanagar", lat: 12.9352, lon: 77.5945, intensity: 81, cancellations: 9 },
    { zone: "Brookefield", lat: 12.9698, lon: 77.7166, intensity: 76, cancellations: 4 },
    { zone: "CBD Bellandur", lat: 12.9352, lon: 77.685, intensity: 89, cancellations: 11 },
  ]

  const cancellationByZone = useMemo(() => {
    return hotspots
      .map((h) => ({ name: h.zone, cancellations: h.cancellations }))
      .sort((a, b) => b.cancellations - a.cancellations)
  }, [])

  const intensityData = useMemo(() => {
    return hotspots.map((h) => ({ name: h.zone, intensity: h.intensity })).sort((a, b) => b.intensity - a.intensity)
  }, [])

  const scatterData = useMemo(() => {
    return hotspots.map((h) => ({ x: h.lon, y: h.lat, z: h.intensity, name: h.zone, cancellations: h.cancellations }))
  }, [])

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-cyan-400">Geo-Spatial Analysis</CardTitle>
          <CardDescription className="text-slate-400">
            High-demand zones, cancellation hotspots & peak-hour patterns
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="heatmap" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-slate-800 border-slate-700">
              <TabsTrigger value="heatmap" className="data-[state=active]:bg-cyan-500 data-[state=active]:text-black">
                Demand Heatmap
              </TabsTrigger>
              <TabsTrigger
                value="cancellations"
                className="data-[state=active]:bg-pink-500 data-[state=active]:text-black"
              >
                Cancellations
              </TabsTrigger>
              <TabsTrigger value="scatter" className="data-[state=active]:bg-purple-500 data-[state=active]:text-black">
                Geo Scatter
              </TabsTrigger>
            </TabsList>

            <TabsContent value="heatmap" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={intensityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                  />
                  <Bar dataKey="intensity" fill="#06b6d4" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
              <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                {hotspots.slice(0, 6).map((h) => (
                  <div key={h.zone} className="p-2 bg-slate-800 rounded border border-slate-700">
                    <p className="font-semibold text-cyan-400">{h.zone}</p>
                    <p className="text-slate-400">Intensity: {h.intensity}%</p>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="cancellations" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={cancellationByZone} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis type="number" stroke="#94a3b8" />
                  <YAxis dataKey="name" width={100} stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                  />
                  <Bar dataKey="cancellations" fill="#ec4899" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="scatter" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    dataKey="x"
                    type="number"
                    stroke="#94a3b8"
                    label={{ value: "Longitude", position: "insideBottomRight", offset: -5, fill: "#94a3b8" }}
                  />
                  <YAxis
                    dataKey="y"
                    type="number"
                    stroke="#94a3b8"
                    label={{ value: "Latitude", angle: -90, position: "insideLeft", fill: "#94a3b8" }}
                  />
                  <Tooltip
                    cursor={{ strokeDasharray: "3 3" }}
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                  />
                  <Scatter name="Zone Demand" data={scatterData} fill="#06b6d4" stroke="#06b6d4" />
                </ScatterChart>
              </ResponsiveContainer>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
