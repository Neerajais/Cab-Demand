"use client"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CancellationPrediction() {
  const highRiskRides = [
    { rideId: 101, zone: "MG Road", probability: 0.78, factors: ["high_surge", "late_night"] },
    { rideId: 102, zone: "CBD Bellandur", probability: 0.72, factors: ["long_distance", "late_night"] },
    { rideId: 103, zone: "Whitefield", probability: 0.68, factors: ["high_surge"] },
  ]

  const cancellationRateByZone = [
    { zone: "MG Road", rate: 18.5 },
    { zone: "CBD Bellandur", rate: 15.2 },
    { zone: "Majestic", rate: 14.8 },
    { zone: "Koramangala", rate: 12.3 },
    { zone: "Indiranagar", rate: 11.8 },
    { zone: "Whitefield", rate: 8.6 },
  ]

  const riskDistribution = [
    { name: "High Risk", value: 35, fill: "#ef4444" },
    { name: "Medium Risk", value: 45, fill: "#f97316" },
    { name: "Low Risk", value: 20, fill: "#22c55e" },
  ]

  const timeOfDayRisks = [
    { hour: "00:00", risk: 0.75 },
    { hour: "06:00", risk: 0.42 },
    { hour: "12:00", risk: 0.38 },
    { hour: "18:00", risk: 0.65 },
    { hour: "21:00", risk: 0.82 },
    { hour: "23:00", risk: 0.78 },
  ]

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-pink-400">Ride Cancellation Prediction</CardTitle>
          <CardDescription className="text-slate-400">
            ML-powered predictions (Logistic Regression, Random Forest, XGBoost ensemble)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="risks" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-slate-800 border-slate-700">
              <TabsTrigger
                value="risks"
                className="data-[state=active]:bg-red-500 data-[state=active]:text-black text-xs"
              >
                High Risk
              </TabsTrigger>
              <TabsTrigger
                value="zones"
                className="data-[state=active]:bg-pink-500 data-[state=active]:text-black text-xs"
              >
                By Zone
              </TabsTrigger>
              <TabsTrigger
                value="distribution"
                className="data-[state=active]:bg-orange-500 data-[state=active]:text-black text-xs"
              >
                Distribution
              </TabsTrigger>
              <TabsTrigger
                value="timeline"
                className="data-[state=active]:bg-yellow-500 data-[state=active]:text-black text-xs"
              >
                Time Pattern
              </TabsTrigger>
            </TabsList>

            <TabsContent value="risks" className="mt-6">
              <div className="space-y-3">
                {highRiskRides.map((ride) => (
                  <div
                    key={ride.rideId}
                    className="p-3 bg-slate-800 rounded border border-red-500/30 hover:border-red-500 transition"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-semibold text-red-400">Ride #{ride.rideId}</p>
                        <p className="text-sm text-slate-400">{ride.zone}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-red-500">{(ride.probability * 100).toFixed(0)}%</p>
                        <p className="text-xs text-slate-400">Cancel Risk</p>
                      </div>
                    </div>
                    <div className="mt-2 flex gap-1 flex-wrap">
                      {ride.factors.map((factor) => (
                        <span key={factor} className="px-2 py-1 text-xs bg-red-500/20 text-red-300 rounded">
                          {factor.replace("_", " ")}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="zones" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={cancellationRateByZone} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis type="number" stroke="#94a3b8" />
                  <YAxis dataKey="zone" width={120} stroke="#94a3b8" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value) => `${value.toFixed(1)}%`}
                  />
                  <Bar dataKey="rate" fill="#ec4899" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="distribution" className="mt-6 flex justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={riskDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name} ${value}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {riskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="timeline" className="mt-6">
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={timeOfDayRisks}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="hour" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "1px solid #475569",
                      borderRadius: "8px",
                      color: "#e2e8f0",
                    }}
                    formatter={(value) => `${(value * 100).toFixed(0)}%`}
                  />
                  <Line type="monotone" dataKey="risk" stroke="#f97316" strokeWidth={2} dot={{ fill: "#f97316" }} />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
