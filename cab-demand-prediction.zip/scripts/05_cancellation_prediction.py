import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from datetime import datetime

def extract_cancellation_features(rides_df):
    """Extract features for cancellation prediction"""
    
    features_df = rides_df.copy()
    
    # Temporal features
    features_df['hour'] = pd.to_datetime(features_df['pickup_datetime']).dt.hour
    features_df['day_of_week'] = pd.to_datetime(features_df['pickup_datetime']).dt.dayofweek
    features_df['is_weekend'] = features_df['day_of_week'].isin([5, 6]).astype(int)
    
    # Zone-based features
    features_df['pickup_zone_id'] = features_df['pickup_zone_id'].fillna(0)
    features_df['drop_zone_id'] = features_df['drop_zone_id'].fillna(0)
    
    # Distance feature (approximation)
    features_df['distance_km'] = features_df.get('distance_km', 5.0).fillna(5.0)
    
    # Demand features
    zone_demand = rides_df.groupby('pickup_zone_id').size()
    features_df['zone_demand'] = features_df['pickup_zone_id'].map(zone_demand).fillna(zone_demand.mean())
    
    # Surge feature
    features_df['surge_multiplier'] = features_df.get('surge_multiplier', 1.0).fillna(1.0)
    
    return features_df[['hour', 'day_of_week', 'is_weekend', 'pickup_zone_id', 
                       'distance_km', 'zone_demand', 'surge_multiplier']]


def train_cancellation_model(rides_df):
    """Train multiple cancellation prediction models"""
    
    X = extract_cancellation_features(rides_df)
    y = rides_df['ride_cancelled'].astype(int)
    
    # Handle missing values
    X = X.fillna(X.mean())
    
    # Normalize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Train multiple models
    models = {
        'logistic_regression': LogisticRegression(max_iter=1000, random_state=42),
        'random_forest': RandomForestClassifier(n_estimators=100, random_state=42, max_depth=10),
        'gradient_boosting': GradientBoostingClassifier(n_estimators=100, random_state=42, max_depth=5)
    }
    
    trained_models = {}
    for name, model in models.items():
        model.fit(X_scaled, y)
        trained_models[name] = model
    
    return trained_models, scaler, X.columns.tolist()


def predict_cancellation_probability(ride_data, models, scaler, feature_columns):
    """Predict cancellation probability for a ride"""
    
    # Prepare data
    X = pd.DataFrame([ride_data], columns=feature_columns)
    X = X.fillna(X.mean())
    X_scaled = scaler.transform(X)
    
    # Ensemble prediction (average of all models)
    probabilities = []
    for model in models.values():
        prob = model.predict_proba(X_scaled)[0][1]
        probabilities.append(prob)
    
    avg_probability = np.mean(probabilities)
    
    # Risk factors
    risk_factors = []
    if ride_data.get('surge_multiplier', 1.0) > 1.5:
        risk_factors.append('high_surge')
    if ride_data.get('hour', 0) in [22, 23, 0, 1]:
        risk_factors.append('late_night')
    if ride_data.get('distance_km', 5) > 15:
        risk_factors.append('long_distance')
    
    return {
        'cancellation_probability': avg_probability,
        'risk_factors': risk_factors,
        'risk_level': 'high' if avg_probability > 0.6 else 'medium' if avg_probability > 0.3 else 'low'
    }


def generate_cancellation_insights():
    """Generate sample cancellation insights for frontend"""
    return {
        "high_risk_rides": [
            {"ride_id": 101, "zone": "MG Road", "probability": 0.78, "factors": ["high_surge", "late_night"]},
            {"ride_id": 102, "zone": "CBD Bellandur", "probability": 0.72, "factors": ["long_distance", "late_night"]},
            {"ride_id": 103, "zone": "Whitefield", "probability": 0.68, "factors": ["high_surge"]},
        ],
        "medium_risk_rides": [
            {"ride_id": 104, "zone": "Koramangala", "probability": 0.45, "factors": ["high_surge"]},
            {"ride_id": 105, "zone": "Indiranagar", "probability": 0.42, "factors": ["distance_km"]},
        ],
        "cancellation_rate_by_zone": {
            "MG Road": 18.5,
            "CBD Bellandur": 15.2,
            "Koramangala": 12.3,
            "Majestic": 14.8,
            "Whitefield": 8.6
        }
    }

if __name__ == "__main__":
    insights = generate_cancellation_insights()
    print("Cancellation Prediction Insights:")
    for ride in insights['high_risk_rides'][:2]:
        print(f"  Ride {ride['ride_id']}: {ride['probability']:.2%} cancellation risk")
